 # Dalton Reische
 # 7/3/2024
 # P4LAB1a
 # Drawing shapes with turtle

#Import/setup
import turtle
wn = turtle.Screen()
wn.bgcolor("black")      
wn.title("P4LAB1a")      

t = turtle.Turtle()
t.color("red")           
t.pensize(3)

#Triangle
for i in [0,1,2]:
    t.forward(100)
    t.left(120)

t.penup()
t.forward(150)
t.pendown()

#Square
for i in [0,1,2,3]:
    t.forward(50)
    t.left(90)

wn.mainloop()
