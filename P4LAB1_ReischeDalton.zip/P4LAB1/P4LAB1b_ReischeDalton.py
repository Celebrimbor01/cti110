 # Dalton Reische
 # 7/3/2024
 # P4LAB1b
 # Drawing initials with turtle

#Import/setup
import turtle
wn = turtle.Screen()
wn.bgcolor("black")      
wn.title("P4LAB1b")      

t = turtle.Turtle()
t.color("red")           
t.pensize(3)

#Initial D

t.right(90)
t.forward(100)
t.left(90)
t.circle(100,180)
t.left(90)
t.forward(100)

t.penup()
t.forward(100)
t.left(90)
t.forward(200)
t.pendown()

#Initial R

t.circle(80,180)
t.left(90)
t.forward(290)
t.backward(125)
t.left(45)
t.forward(150)

wn.mainloop()
